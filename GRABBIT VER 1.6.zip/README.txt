OwO What's this? it's GRABBIT!
A folder will be automatically created in Documents titled "Grabbit Downloads", this is the default
save location if one has not been specified under the "Settings" menu
Videos will be saved as .mp4s, Music will be saved as .mp3s

If you are downloading more than one video or song at any time, select Download Playlist. A popout menu will appear.
If you're curious what sites youtube-dl can download from, select "Supported Sites" under the "About" menu.

!TROUBLESHOOTING!
If media is failing to download, attempt updating youtube-dl from the "Settings" menu.
As websites change and update, youtube-dl must be updated to keep up with them.
Some media with non-ASCII characters present in the name will fail to download. This has been mitigated as best I can, but
is ultimately an issue with youtube-dl itself.